const close = document.querySelector('.sidebar')


function openSideBar() {
    close.style.display = "flex";
}

function closeSideBar() {
    close.style.display = "none";
}


